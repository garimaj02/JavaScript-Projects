let  imgBox = document.getElementById("img-box");
let  QRimage = document.getElementById("QRimage");
let  QRText = document.getElementById("QRText");

function GenerateQR(){
       QRimage.src = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" + QRText.value;
}
const inputBox = document.getElementById("input-box");

const listContainer = document.getElementById("list-container");

// function for adding a task

function addTask(){
    if(inputBox.value === ''){
        alert("You must write something!");
    }
    else{
        let li  = document.createElement("li");
        li.innerHTML = inputBox.value;
        listContainer.appendChild(li);
        let span = document.createElement("span");
        span.innerHTML =  "\u00d7";
        li.appendChild(span);

        // // Create Set Reminder button
        // let reminderButton = document.createElement("button");
        // reminderButton.textContent = "Set Reminder";
        // reminderButton.onclick = function() {
        //     setReminder(li);
        // };
        // li.appendChild(reminderButton);
    
    }
    inputBox.value = "";
    saveData();
}

// for remove task from the list

listContainer.addEventListener("click", function(e) {
    if (e.target.tagName === "LI") {
        e.target.classList.toggle("checked");
        saveData();
    } else if (e.target.tagName === "SPAN") {
        e.target.parentElement.remove();
    }
}, false);

// save the data in local storage
function saveData(){
    localStorage.setItem("data",listContainer.innerHTML);
}

// for showing the task from the localStorage

function showTask(){
  listContainer.innerHTML = localStorage.getItem("data")
}

showTask();

// this is for updating the task

function updateTask(li) {
    const newText = prompt("Enter new text:", li.innerText.trim());
    if (newText !== null && newText !== '') {
        li.innerText = newText;
        saveData();
    }
}
listContainer.addEventListener("dblclick", function(e) {
    if (e.target.tagName === "LI") {
        updateTask(e.target);
    }
});

// for set reminder
// // Function to set a reminder
// function setReminder(li) {
//     const reminderDate = prompt("Enter reminder date and time (YYYY-MM-DD HH:MM):");
//     if (reminderDate !== null && reminderDate !== '') {
//         // Store reminder date and time as a data attribute
//         li.setAttribute("data-reminder", reminderDate);
//     }
// }